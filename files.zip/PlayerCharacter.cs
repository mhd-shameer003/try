using UnityEngine;

/// <summary>
/// Core movement/jump controller for a single character (P1 or P2).
/// Works in three modes, selected by the fields below:
///   - Solo "swap" mode:   alwaysControllable = false. Only the character marked
///                         active by PlayerSwapManager responds to input.
///   - Solo "dual-input" mode: alwaysControllable = true on BOTH characters.
///                         Each reads its own key scheme simultaneously.
///   - Networked mode:     controlScheme = Networked. Local input is ignored;
///                         NetworkPlayer (Networking/) drives this via ApplyNetworkMove().
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerCharacter : MonoBehaviour
{
    public enum ControlScheme { WASD, ArrowKeys, Networked, None }

    [Header("Identity")]
    public string characterId = "P1";
    public ControlScheme controlScheme = ControlScheme.WASD;

    [Header("Movement")]
    public float moveSpeed = 5f;
    public float rotationSpeed = 12f;
    public float jumpHeight = 1.6f;
    public float gravity = -18f;
    public float groundedStickGravity = -2f; // small downward force to keep controller grounded on slopes/steps

    [Header("Solo-mode control gating")]
    [Tooltip("True = always responds to input (dual-input solo mode). False = only responds while PlayerSwapManager marks this character active (toggle solo mode).")]
    public bool alwaysControllable = false;

    CharacterController controller;
    Vector3 velocity;
    bool isActiveForSwap = true; // written by PlayerSwapManager, ignored if alwaysControllable

    public bool IsGrounded => controller.isGrounded;
    public Vector3 CurrentVelocity => velocity;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    /// <summary>Called by PlayerSwapManager when the active character changes.</summary>
    public void SetActiveForSwap(bool active) => isActiveForSwap = active;

    bool LocalInputEnabled =>
        controlScheme == ControlScheme.WASD || controlScheme == ControlScheme.ArrowKeys
        ? (alwaysControllable || isActiveForSwap)
        : false;

    void Update()
    {
        if (!LocalInputEnabled)
        {
            ApplyGravityOnly();
            return;
        }

        Vector2 moveInput = ReadMoveAxis();
        bool jumpPressed = ReadJumpPressed();

        ApplyMovement(moveInput);
        ApplyJumpAndGravity(jumpPressed);
    }

    Vector2 ReadMoveAxis()
    {
        float h = 0f, v = 0f;
        if (controlScheme == ControlScheme.WASD)
        {
            if (Input.GetKey(KeyCode.A)) h -= 1f;
            if (Input.GetKey(KeyCode.D)) h += 1f;
            if (Input.GetKey(KeyCode.W)) v += 1f;
            if (Input.GetKey(KeyCode.S)) v -= 1f;
        }
        else if (controlScheme == ControlScheme.ArrowKeys)
        {
            if (Input.GetKey(KeyCode.LeftArrow)) h -= 1f;
            if (Input.GetKey(KeyCode.RightArrow)) h += 1f;
            if (Input.GetKey(KeyCode.UpArrow)) v += 1f;
            if (Input.GetKey(KeyCode.DownArrow)) v -= 1f;
        }

        Vector2 raw = new Vector2(h, v);
        return raw.sqrMagnitude > 1f ? raw.normalized : raw;
    }

    bool ReadJumpPressed()
    {
        // WASD character jumps on Space (matches the spec's keyboard map).
        // ArrowKeys character (used simultaneously in dual-input solo mode,
        // or by a second local player) jumps on Right Shift.
        if (controlScheme == ControlScheme.WASD) return Input.GetKeyDown(KeyCode.Space);
        if (controlScheme == ControlScheme.ArrowKeys) return Input.GetKeyDown(KeyCode.RightShift);
        return false;
    }

    void ApplyMovement(Vector2 moveInput)
    {
        if (moveInput.sqrMagnitude < 0.0001f) return;

        Vector3 camForward = Vector3.forward;
        Vector3 camRight = Vector3.right;
        if (Camera.main != null)
        {
            camForward = Vector3.ProjectOnPlane(Camera.main.transform.forward, Vector3.up).normalized;
            camRight = Vector3.ProjectOnPlane(Camera.main.transform.right, Vector3.up).normalized;
        }

        Vector3 worldMove = camForward * moveInput.y + camRight * moveInput.x;
        controller.Move(worldMove * moveSpeed * Time.deltaTime);

        if (worldMove.sqrMagnitude > 0.0001f)
        {
            Quaternion targetRot = Quaternion.LookRotation(worldMove, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
        }
    }

    void ApplyJumpAndGravity(bool jumpPressed)
    {
        if (controller.isGrounded)
        {
            velocity.y = groundedStickGravity;
            if (jumpPressed)
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }
        else
        {
            velocity.y += gravity * Time.deltaTime;
        }
        controller.Move(velocity * Time.deltaTime);
    }

    void ApplyGravityOnly()
    {
        if (controller.isGrounded) velocity.y = groundedStickGravity;
        else velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    /// <summary>Entry point for Networking/NetworkPlayer.cs to drive this character
    /// from replicated input on non-authoritative clients, bypassing local Input calls.</summary>
    public void ApplyNetworkMove(Vector2 moveInput, bool jumpPressed)
    {
        ApplyMovement(moveInput);
        ApplyJumpAndGravity(jumpPressed);
    }
}
