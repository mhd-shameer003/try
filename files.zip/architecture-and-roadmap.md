# Bound Duo — 3D Co-op Puzzle Platformer
## Technical Architecture & Roadmap

---

## 1. Engine Recommendation

Your spec has three demands that pull in different directions: **fast iteration** (you've been shipping single-file prototypes), **real multiplayer** (P2P/networked co-op), and **mobile + PC distribution** (touch controls, app stores). No single tool is best at all three, so the honest recommendation is a **two-phase pipeline**, not a single engine pick.

| | Three.js (Web) | Unity (C#) | Unreal (C++/BP) |
|---|---|---|---|
| Time to first playable | Hours | Days | Days–weeks |
| Physics/character controller | Manual (cannon-es / Rapier) | Built-in `CharacterController` | Built-in, very robust |
| Networking | DIY (Colyseus/WebRTC) | Netcode for GameObjects + Relay, or Photon Fusion (turnkey) | Replication built-in, heavier setup |
| Mobile export | PWA/Capacitor wrapper (extra step) | Native, first-class | Native, but heavy binaries |
| Asset/animation pipeline | Manual | Mature (Mecanim, Timeline) | Best-in-class, overkill here |
| App store presence | Weak without wrapping | Strong | Strong |
| Fits your current workflow | ✅ Yes | ❌ New tooling | ❌ New tooling |

**Recommendation:**
- **Phase 0 (Prototype, now):** Build the core loop in **Three.js + Rapier.js (WASM physics)** in this chat. You get an instantly playable vertical slice (movement, jump, one puzzle, camera) — the same iteration speed as your past builds, just in 3D. This is where we validate "does the co-op feel good" before investing in a heavier engine.
- **Phase 1 (Production, later):** Port validated mechanics to **Unity (C#)** once you're happy with the feel. Unity gives you real touch input (via the new Input System), a mature `CharacterController`, and a turnkey netcode stack (Netcode for GameObjects + Unity Relay for free NAT punch-through, or Photon Fusion if you want managed servers). This is what you'd actually submit to app stores.
- **Unreal is not recommended** for this project — it's built for AAA-fidelity visuals and large teams; for a stylized co-op puzzler it adds build-time and learning-curve cost with no gameplay benefit.

Below, the player controller is written in **C# for Unity**, since that's your eventual shipping target and the code maps 1:1 onto the architecture — but I can also spin up a live Three.js prototype in this chat if you want something clickable today. Just say the word.

---

## 2. High-Level Module Architecture

```
BoundDuo/
├── Core/
│   ├── GameManager.cs          — scene flow, pause, win/lose state
│   ├── InputRouter.cs          — abstracts KB/gamepad/touch into one input struct
│   └── SaveSystem.cs           — level unlocks, star ratings, cosmetics
│
├── Characters/
│   ├── PlayerCharacter.cs      — physics, movement, jump, per-character state
│   ├── PlayerSwapManager.cs    — solo-mode active-character toggling
│   ├── PlayerInteractor.cs     — raycast/trigger-based grab & lever use
│   └── CharacterCosmetics.cs   — skin/material swap
│
├── Camera/
│   └── DualTargetCamera.cs     — frames both players, auto zoom/pan
│
├── Puzzle/
│   ├── IInteractable.cs        — interface: levers, buttons, pickups
│   ├── IWeightTrigger.cs       — interface: pressure plates
│   ├── PressurePlate.cs
│   ├── Lever.cs
│   ├── Gate.cs                 — listens to N triggers (AND/OR configurable)
│   ├── MovableBlock.cs         — pushable crate (Rigidbody + push constraints)
│   └── AsymmetricPlatform.cs   — P1 button opens path only for P2
│
├── Hazards/
│   ├── HazardBase.cs           — abstract "on touch -> respawn" behaviour
│   ├── Spikes.cs
│   ├── SawBlade.cs             — patrol/rotate hazard
│   ├── CollapsingFloor.cs      — timed trigger + respawn
│   └── WaterHazard.cs
│
├── Progression/
│   ├── LevelData.cs (ScriptableObject) — level manifest: spawn points, par time, star thresholds
│   ├── StarEvaluator.cs        — time + collectibles -> 1–3 stars
│   └── LevelSelectController.cs
│
├── Networking/
│   ├── NetworkPlayer.cs        — NGO NetworkBehaviour wrapper around PlayerCharacter
│   ├── LobbyManager.cs         — room code create/join via Unity Relay
│   └── NetworkedPuzzleSync.cs  — syncs gate/plate/crate state across clients
│
└── UI/
    ├── TouchControls.cs        — virtual joystick, jump/interact/swap buttons
    ├── HUD.cs
    └── LobbyUI.cs
```

**Why this shape:** every puzzle element (`PressurePlate`, `Lever`, `MovableBlock`) implements a shared interface (`IInteractable` / `IWeightTrigger`) and reports state changes to `Gate` via events — the Gate doesn't know or care *what* triggered it, just how many of its linked triggers are active. This is the same pattern that made the 2D prototype's level data clean (plates/levers → gates, keyed by id), just promoted to interfaces so designers can wire new puzzle types without touching Gate code.

---

## 3. Data-Driven Levels

Levels should **not** be hardcoded in scripts. Use a `LevelData` ScriptableObject (or JSON if you go Three.js) holding:

```
LevelData
├── levelId, displayName, parTimeSeconds
├── p1SpawnPoint, p2SpawnPoint
├── collectibles[]           (position, id)
├── starThresholds[3]        (time in seconds for 1/2/3 stars)
└── sceneReference           (Addressable/scene path)
```

The actual geometry lives in the Unity scene (or a glTF scene in Three.js); `LevelData` is metadata the progression system reads. This keeps level *design* (block-out in-editor) separate from level *bookkeeping* (stars, unlocks), so a level designer never touches C#.

---

## 4. Networking Strategy (Co-op Mode)

- **Authority model:** Host-authoritative (one player is host, matches Pepelo's likely architecture for a 2-player game — avoids full dedicated-server cost).
- **Stack:** Unity **Netcode for GameObjects** + **Unity Relay** (handles NAT traversal so "room code" pairing works without port-forwarding) + **Unity Lobby** (for the room-code/matchmaking UI itself).
- **What syncs:** player transform/animation state (via `NetworkTransform`), and puzzle-object state (`NetworkVariable<bool>` on gates/plates) — not raw physics, to avoid desync on crates. Crates should be host-simulated and position-synced to the client, not independently simulated on both machines.
- **Solo mode reuses the same `PlayerCharacter` class** — it just runs two local instances instead of one local + one networked, so you don't fork your gameplay code for online vs. offline.

---

## 5. Step-by-Step Roadmap

**Milestone 0 — Feel Prototype (Three.js, 1 sprint)**
- Single capsule character, third-person camera, jump, one moving platform, one pressure-plate-gate puzzle. Goal: prove the core "two bodies, one puzzle" loop is fun before writing production code.

**Milestone 1 — Unity Core Controller (this deliverable)**
- Port `PlayerCharacter` + `PlayerSwapManager` into Unity. Two characters, solo dual-control, Tab-swap. No puzzles yet — just a flat gray-box level to test movement feel.

**Milestone 2 — Puzzle Systems**
- Implement `IInteractable`/`IWeightTrigger`, `PressurePlate`, `Lever`, `Gate`, `MovableBlock`, `AsymmetricPlatform`. Build 3 gray-box levels, one per new mechanic, exactly like the 2D prototype's level 1–4 structure.

**Milestone 3 — Hazards & Fail States**
- `HazardBase` + Spikes/SawBlade/CollapsingFloor/Water, respawn-to-checkpoint flow, simple particle/screen-flash feedback.

**Milestone 4 — Camera & Controls Polish**
- `DualTargetCamera` (frame both players, auto-zoom on separation), touch controls (`TouchControls.cs`), gamepad support via new Input System.

**Milestone 5 — Progression**
- `LevelData` ScriptableObjects for 10 levels, `StarEvaluator`, level-select screen, save/unlock system.

**Milestone 6 — Networking**
- Wrap `PlayerCharacter` in `NetworkPlayer`, add `LobbyManager` (room code create/join via Unity Lobby+Relay), sync puzzle state via `NetworkVariable`s. Test 2-player over LAN, then over Relay.

**Milestone 7 — Cosmetics & Content Scale-up**
- Skin system, expand from 10 → 30–50 levels reusing the mechanic library, polish pass (VFX, audio, UI).

Each milestone should be independently playable and demoable — that's the same "ship something testable every step" pattern from the 2D build, just scoped to a real production pipeline instead of one file.

---

## 6. What I'd build next, concretely

Given this roadmap, the highest-leverage next artifact is **Milestone 1**: the player controller + swap manager, ready to drop into a fresh Unity project on a flat plane. That's what's in `PlayerCharacter.cs` and `PlayerSwapManager.cs` alongside this document.
