using UnityEngine;

/// <summary>
/// Drives solo-mode control in "toggle" mode: only one of the two characters
/// accepts input at a time, and Tab swaps which one. Has no effect on
/// characters whose PlayerCharacter.alwaysControllable is true (dual-input
/// solo mode) — those already always respond to their own key scheme.
/// Hook OnActiveCharacterChanged to DualTargetCamera or a swap-flash VFX.
/// </summary>
public class PlayerSwapManager : MonoBehaviour
{
    [Header("References")]
    public PlayerCharacter player1;
    public PlayerCharacter player2;

    [Header("Config")]
    public KeyCode swapKey = KeyCode.Tab;
    [Tooltip("If true, both characters are always controllable and this manager only tracks which one the camera should favor — it no longer gates input.")]
    public bool duoInputMode = false;

    int activeIndex = 0; // 0 = player1, 1 = player2

    public System.Action<PlayerCharacter> OnActiveCharacterChanged;

    public PlayerCharacter ActiveCharacter => activeIndex == 0 ? player1 : player2;
    public PlayerCharacter InactiveCharacter => activeIndex == 0 ? player2 : player1;

    void Start()
    {
        ApplyActiveState();
    }

    void Update()
    {
        if (duoInputMode) return;

        if (Input.GetKeyDown(swapKey))
        {
            activeIndex = 1 - activeIndex;
            ApplyActiveState();
        }
    }

    void ApplyActiveState()
    {
        if (!duoInputMode)
        {
            player1.SetActiveForSwap(activeIndex == 0);
            player2.SetActiveForSwap(activeIndex == 1);
        }
        OnActiveCharacterChanged?.Invoke(ActiveCharacter);
    }
}
